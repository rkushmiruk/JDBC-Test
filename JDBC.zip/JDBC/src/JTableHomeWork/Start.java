/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JTableHomeWork;


import java.sql.Connection;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.table.TableModel;


public class Start {
   public static void main(String args[]){
        try{
            Connection con = SQLiteConnection.getConnection();
            TableModel mod = new MyTableModel(con,"spr_Brand");
            JTable jTable = new JTable(mod);
            
            jTable.setDefaultRenderer(Object.class, new MyTableRenderer());
            JScrollPane scroller = new JScrollPane(jTable, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            
            JFrame frame = new JFrame("Загрузка данных в JTable");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.getContentPane().add(scroller);
            frame.pack();
            frame.setVisible(true);
            con.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}

