/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JTable;
import javax.swing.table.*;
import java.sql.*;
import java.util.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
/**
 *
 * @author -DON_RAMINO-
 */
public class MyTableModel extends AbstractTableModel {
    private Object[][] contents;// хранит данные
    private String[] columnNames;// хранит имена столбцов
    
    private Class[] columnClasses;// хранит типы столбцов
    
    public MyTableModel(Connection conn,String tableName) throws SQLException{
        super();
        getTableContents(conn, tableName);
    }
    
    private void getTableContents(Connection conn, String tableName) throws SQLException{
        DatabaseMetaData meta = conn.getMetaData();
        
        ResultSet rs = meta.getColumns(null, null, tableName, null);// получить метаданные по столбцам
        ArrayList colNamesList = new ArrayList();//список имен столбцов
        ArrayList colTypesList = new ArrayList();//список типов столбцов
        
        while(rs.next()){
            colNamesList.add(rs.getString("COLUMN_NAME"));//добавить в список имя столбца
            
            int dbType = rs.getInt("DATA_TYPE");
            
            switch(dbType){
                case Types.INTEGER:
                    colTypesList.add(Integer.class);
                    break;
                case Types.FLOAT:
                    colTypesList.add(Float.class);
                    break;
                case Types.CHAR:
                    colTypesList.add(char.class);
                    break;
                case Types.DATE:
                case Types.TIME:
                case Types.TIMESTAMP:
                 colTypesList.add(java.sql.Date.class);
                    break;
                    default:
                        colTypesList.add(String.class);
                        break;
            }
            
        }
        
        //имена столбцов сохранить в отдельный массив columnNames
        columnNames = new String[colNamesList.size()];
        colNamesList.toArray(columnNames);
        // типы столбцов сохранить в отдельный массив columnClasses
        columnClasses = new Class[colTypesList.size()];
        colTypesList.toArray(columnClasses);
        
        Statement statement = conn.createStatement();
        rs = statement.executeQuery("SELECT * FROM "+ tableName+" GROUP BY name_ru");
        
        ArrayList rowList = new ArrayList();// хранит записи из таблицы
        
        while(rs.next()){
            ArrayList cellList = new ArrayList();// хранит данные по каждому столбцу(ячейки)
            
            for(int i=0; i<columnClasses.length;i++){
                Object cellValue = null;
                if(columnClasses[i] == String.class) cellValue = rs.getString(columnNames[i]);
                else if(columnClasses[i] == Integer.class) cellValue = new Integer(rs.getInt(columnNames[i]));
                else System.out.println("Не могу определить тип поля"+ columnNames[i]);// все типы нужно указать тут только 2
                
                cellList.add(cellValue);
                
            }//for
            Object[] cells = cellList.toArray();
            rowList.add(cells);
            
        }// while
        
        contents = new Object[rowList.size()][];
        for(int i=0; i<contents.length;i++){
            contents[i] = (Object[]) rowList.get(i);
        }
        rs.close();
        statement.close();
        
    }

   

    @Override
    public <T extends EventListener> T[] getListeners(Class<T> listenerType) {
        return super.getListeners(listenerType); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableChanged(TableModelEvent e) {
        super.fireTableChanged(e); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableCellUpdated(int row, int column) {
        super.fireTableCellUpdated(row, column); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableRowsDeleted(int firstRow, int lastRow) {
        super.fireTableRowsDeleted(firstRow, lastRow); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableRowsUpdated(int firstRow, int lastRow) {
        super.fireTableRowsUpdated(firstRow, lastRow); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableRowsInserted(int firstRow, int lastRow) {
        super.fireTableRowsInserted(firstRow, lastRow); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableStructureChanged() {
        super.fireTableStructureChanged(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableDataChanged() {
        super.fireTableDataChanged(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TableModelListener[] getTableModelListeners() {
        return super.getTableModelListeners(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        super.removeTableModelListener(l); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        super.addTableModelListener(l); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        super.setValueAt(aValue, rowIndex, columnIndex); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return super.isCellEditable(rowIndex, columnIndex); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return super.getColumnClass(columnIndex); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int findColumn(String columnName) {
        return super.findColumn(columnName); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int column) {
        return super.getColumnName(column); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getRowCount() {
        return contents.length;
    }

   

    @Override
    public int getColumnCount() {
        if(contents.length ==0){
            return 0;
        }else{
            return contents[0].length;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        return contents[row][column];
    }
    
}
