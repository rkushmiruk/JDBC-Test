
package Lesson1;

import java.sql.*;

public class Lesson {
    public static void main(String args[]){
        Connection con = null;// хранит соединение 
        Statement stmt = null;// хранит и выполняет sql запросы
        ResultSet res = null; //результат выполнения sql запросов
        try{
            // Динамическая регистрация драйвера SqlLite
            Driver d = (Driver) Class.forName("org.sqlite.JDBC").newInstance();
//            DriverManager.registerDriver(d);
            
            //создание подключения к базе данных по пути указанному в урле
            String url = "jdbc:sqlite:C:\\Users\\-DON_RAMINO-\\Desktop\\Roman Brovko\\CarShop.db";
            con = DriverManager.getConnection(url);
            //подготовка sql запроса
            String sql = "SELECT * FROM spr_Model";
            stmt = con.createStatement();
            //выполнение sql запроса
            res = stmt.executeQuery(sql);
            //обработка рещультатов
            while (res.next()){
                System.out.println(res.getString("name_en")+" - "+ res.getObject("name_ru"));
                
            }
            
            
        }catch(SQLException e){
            e.printStackTrace();
        }catch(Exception e){
            e.printStackTrace();
            
        } finally{
            try{
                if (res!=null)res.close();
                if (stmt!=null)stmt.close();
                if (con!=null)con.close();
            } catch(Exception ex){
                
            }
        }
        
        
            
        
              
    }
}
