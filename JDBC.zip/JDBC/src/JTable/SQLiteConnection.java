/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JTable;


import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author -DON_RAMINO-
 */
public class SQLiteConnection {
    private static Connection con;
    public static Connection getConnection() throws InstantiationException{
    try{
         Driver driver = (Driver) Class.forName("org.sqlite.JDBC").newInstance();
            String url = "jdbc:sqlite:C:\\Users\\-DON_RAMINO-\\Desktop\\Roman Brovko\\CarShop.db";
            if(con ==null)    con  = DriverManager.getConnection(url);
            return con;
        }catch(SQLException e){
            Logger.getLogger(SQLiteConnection.class.getName()).log(Level.SEVERE,null,e);
        } catch(ClassNotFoundException e){
            Logger.getLogger(SQLiteConnection.class.getName()).log(Level.SEVERE,null,e);
        } catch(IllegalAccessException ex){
             Logger.getLogger(SQLiteConnection.class.getName()).log(Level.SEVERE,null,ex);
        }
    return null;
    }
}
