/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JTableHomeWork;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.EventListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author -DON_RAMINO-
 */
public class MyTableModel extends AbstractTableModel {
    private Object[][] contents;// хранит данные
    private String[] columnNames;// хранит имена столбцов
    
    private Class[] columnClasses;// хранит типы столбцов
    
    public MyTableModel(Connection conn,String tableName) throws SQLException, IOException{
        super();
        getTableContents(conn, tableName);
    }
    
    private void getTableContents(Connection conn, String tableName) throws SQLException, IOException{
        DatabaseMetaData meta = conn.getMetaData();
        
        ResultSet rs = meta.getColumns(null, null, tableName, null);
        ArrayList colNamesList = new ArrayList();
        ArrayList colTypesList = new ArrayList();
        
        while(rs.next()){
            colNamesList.add(rs.getString("COLUMN_Name"));
            
            int dbType = rs.getInt("DATA_TYPE");
             switch(dbType){
                case Types.INTEGER:
                    colTypesList.add(Integer.class);
                    break;
                case Types.FLOAT:
                    colTypesList.add(Float.class);
                    break;
                case Types.CHAR:
                    colTypesList.add(char.class);
                    break;
                case Types.DATE:
                case Types.TIME:
                case Types.TIMESTAMP:
                 colTypesList.add(java.sql.Date.class);
                    break;
                    default:
                        colTypesList.add(String.class);
                        break;
            
        }
        }
     columnNames = new String[colNamesList.size()];
     colNamesList.toArray(columnNames);
     
     columnClasses = new Class[colTypesList.size()];
     colTypesList.toArray(columnClasses);
     
     Statement statement = conn.createStatement();
     
     BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
     System.out.println("Хотите вести запрос, если нет введите 'NoSql': ");
     if (br.readLine().equals("Yes")){
         System.out.println("Введите запрос:");
         String sql = br.readLine();
         
     rs = statement.executeQuery(sql);//запрос
     
     
     
     
     ArrayList rowList = new ArrayList();
     
     while(rs.next()){
         ArrayList cellList = new ArrayList();
         
         for(int i=0;i<columnClasses.length;i++){
             Object cellValue = null;
              if(columnClasses[i] == String.class) cellValue = rs.getString(columnNames[i]);
                else if(columnClasses[i] == Integer.class) cellValue = new Integer(rs.getInt(columnNames[i]));
                else if(columnClasses[i]== Float.class) cellValue = new Float(rs.getFloat(columnNames[i]));
                else if(columnClasses[i] == Double.class) cellValue = new Double(rs.getDouble(columnNames[i]));
                else if(columnClasses[i]== java.sql.Date.class) cellValue = rs.getDate(columnNames[i]);
                else System.out.println("Не могу определить тип поля"+ columnNames[i]);
             
              cellList.add(cellValue);
         }
         Object[] cells = cellList.toArray();
         rowList.add(cells);
        
     }
     contents = new Object[rowList.size()][];
     for(int i=0; i<contents.length;i++){
         contents[i] = (Object[]) rowList.get(i);
         
     }
     rs.close();
     statement.close();
    
     }   
    }
    
    @Override
    public <T extends EventListener> T[] getListeners(Class<T> listenerType) {
        return super.getListeners(listenerType); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableChanged(TableModelEvent e) {
        super.fireTableChanged(e); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableCellUpdated(int row, int column) {
        super.fireTableCellUpdated(row, column); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableRowsDeleted(int firstRow, int lastRow) {
        super.fireTableRowsDeleted(firstRow, lastRow); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableRowsUpdated(int firstRow, int lastRow) {
        super.fireTableRowsUpdated(firstRow, lastRow); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableRowsInserted(int firstRow, int lastRow) {
        super.fireTableRowsInserted(firstRow, lastRow); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableStructureChanged() {
        super.fireTableStructureChanged(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void fireTableDataChanged() {
        super.fireTableDataChanged(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public TableModelListener[] getTableModelListeners() {
        return super.getTableModelListeners(); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void removeTableModelListener(TableModelListener l) {
        super.removeTableModelListener(l); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void addTableModelListener(TableModelListener l) {
        super.addTableModelListener(l); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
        super.setValueAt(aValue, rowIndex, columnIndex); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return super.isCellEditable(rowIndex, columnIndex); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return super.getColumnClass(columnIndex); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int findColumn(String columnName) {
        return super.findColumn(columnName); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int column) {
        return super.getColumnName(column); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getRowCount() {
        return contents.length;
    }

   

    @Override
    public int getColumnCount() {
        if(contents.length ==0){
            return 0;
        }else{
            return contents[0].length;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        return contents[row][column];
    }
    
}


